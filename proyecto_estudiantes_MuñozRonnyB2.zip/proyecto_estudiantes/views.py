from models import Estudiante, CAMPOS_ESTUDIANTE
from shared.json_manager import GestorJSON
from shared.herramientas import es_email_valido

gestor = GestorJSON("data/estudiantes.json")

# TUPLAS de configuración: fijas, nadie las modifica en tiempo de ejecución
CAMPOS_OBLIGATORIOS = ("nombre", "apellido", "email", "carnet")
CAMPOS_BUSCABLES = ("nombre", "apellido", "email", "carnet")
NOTA_MINIMA = 0
NOTA_MAXIMA = 20


# ===================== AYUDAS INTERNAS =====================
def emails_registrados(excepto_id=None):
    """CONJUNTO con los emails ya usados. Sirve para detectar duplicados al instante."""
    return {
        registro["email"].lower()
        for registro in gestor.leer()
        if registro["id"] != excepto_id
    }


def carnets_registrados(excepto_id=None):
    """CONJUNTO con los carnets ya usados (en mayúsculas para comparar sin errores)."""
    return {
        registro["carnet"].upper()
        for registro in gestor.leer()
        if registro["id"] != excepto_id
    }


def siguiente_id():
    ids = [registro["id"] for registro in gestor.leer()]
    return max(ids) + 1 if ids else 1


def normalizar_materia(texto):
    """'  matemática ' y 'MATEMÁTICA' se guardan igual: 'Matemática'.
    Así el SET de materias no queda con la misma materia escrita de tres formas."""
    texto = texto.strip()
    return texto[:1].upper() + texto[1:].lower()


# ===================== C · CREATE =====================
def crear_estudiante(datos):
    """datos: diccionario con las claves de CAMPOS_ESTUDIANTE. Devuelve (exito, mensaje)."""
    try:
        # 1) Normalizo: un diccionario con todos los campos, sin espacios sobrantes
        valores = {campo: str(datos.get(campo, "")).strip() for campo in CAMPOS_ESTUDIANTE}

        # 2) Reviso obligatorios recorriendo la TUPLA
        faltantes = [campo for campo in CAMPOS_OBLIGATORIOS if not valores[campo]]
        if faltantes:
            return False, f"Faltan campos obligatorios: {', '.join(faltantes)}"

        # 3) Formato del email
        if not es_email_valido(valores["email"]):
            return False, f"El email '{valores['email']}' no tiene un formato válido"

        # 4) Duplicados: búsqueda instantánea dentro de dos CONJUNTOS
        if valores["email"].lower() in emails_registrados():
            return False, "Ese email ya está registrado"
        if valores["carnet"].upper() in carnets_registrados():
            return False, f"El carnet {valores['carnet'].upper()} ya está registrado"

        # 5) Guardo el carnet siempre en mayúsculas y creo el objeto del Modelo
        valores["carnet"] = valores["carnet"].upper()
        estudiante = Estudiante(siguiente_id(), **valores)

        # 6) Agrego a la LISTA y guardo
        registros = gestor.leer()
        registros.append(estudiante.a_diccionario())
        if not gestor.guardar(registros):
            return False, "No se pudo escribir el archivo"
        return True, f"Estudiante {estudiante.obtener_nombre_completo()} creado con id {estudiante.id}"
    except Exception as error:
        return False, f"Error inesperado: {error}"


# ===================== R · READ =====================
def obtener_todos():
    """LISTA de objetos Estudiante."""
    return [Estudiante.desde_diccionario(registro) for registro in gestor.leer()]


def obtener_por_id(id_estudiante):
    for estudiante in obtener_todos():
        if estudiante.id == id_estudiante:
            return estudiante
    return None


# ===================== S · SEARCH =====================
def buscar_estudiantes(termino):
    """Búsqueda lineal: revisa registro por registro los campos de CAMPOS_BUSCABLES."""
    termino = termino.strip().lower()
    if not termino:
        return []
    encontrados = []
    for registro in gestor.leer():
        for campo in CAMPOS_BUSCABLES:                 # recorro la TUPLA de campos
            if termino in str(registro.get(campo, "")).lower():
                encontrados.append(Estudiante.desde_diccionario(registro))
                break                                   # ya coincidió: paso al siguiente
    return encontrados


# ===================== U · UPDATE =====================
def actualizar_estudiante(id_estudiante, cambios):
    """cambios: diccionario solo con los campos que se quieren modificar."""
    try:
        # DIFERENCIA DE CONJUNTOS: ¿mandaron algún campo que no existe?
        desconocidos = set(cambios) - set(CAMPOS_ESTUDIANTE)
        if desconocidos:
            return False, f"Campos no válidos: {', '.join(sorted(desconocidos))}"
        if not cambios:
            return False, "No se indicó ningún cambio"

        if "email" in cambios:
            if not es_email_valido(cambios["email"]):
                return False, "El email no tiene un formato válido"
            if cambios["email"].lower() in emails_registrados(excepto_id=id_estudiante):
                return False, "Ese email ya lo usa otro estudiante"

        if "carnet" in cambios:
            cambios["carnet"] = cambios["carnet"].strip().upper()
            if cambios["carnet"] in carnets_registrados(excepto_id=id_estudiante):
                return False, f"El carnet {cambios['carnet']} ya lo usa otro estudiante"

        registros = gestor.leer()
        posicion = None
        for indice, registro in enumerate(registros):   # enumerate me da índice y valor
            if registro["id"] == id_estudiante:
                posicion = indice
                break
        if posicion is None:
            return False, f"No existe un estudiante con id {id_estudiante}"

        registros[posicion].update(cambios)             # actualizo el diccionario en su lugar
        if not gestor.guardar(registros):
            return False, "No se pudo escribir el archivo"
        return True, f"Estudiante {id_estudiante} actualizado ({len(cambios)} campo/s)"
    except Exception as error:
        return False, f"Error inesperado: {error}"


# ===================== D · DELETE =====================
def eliminar_estudiante(id_estudiante):
    registros = gestor.leer()
    # Construyo una LISTA NUEVA sin ese registro: nunca borro mientras recorro
    quedan = [registro for registro in registros if registro["id"] != id_estudiante]
    if len(quedan) == len(registros):
        return False, f"No existe un estudiante con id {id_estudiante}"
    if not gestor.guardar(quedan):
        return False, "No se pudo escribir el archivo"
    return True, f"Estudiante {id_estudiante} eliminado"


# ===================== NOTAS Y MATERIAS =====================
def agregar_nota(id_estudiante, materia, nota):
    """La nota debe ser un número entre 0 y 20. Devuelve (exito, mensaje)."""
    try:
        materia = normalizar_materia(str(materia))
        if not materia:
            return False, "La materia es obligatoria"

        # Convierto la nota a número: puede llegar como texto desde la Vista
        try:
            nota = float(str(nota).strip().replace(",", "."))
        except ValueError:
            return False, "La nota debe ser un número"
        if not (NOTA_MINIMA <= nota <= NOTA_MAXIMA):
            return False, f"La nota debe estar entre {NOTA_MINIMA} y {NOTA_MAXIMA}"
        if nota == int(nota):
            nota = int(nota)        # 18.0 se guarda como 18

        registros = gestor.leer()
        for indice, registro in enumerate(registros):
            if registro["id"] == id_estudiante:
                estudiante = Estudiante.desde_diccionario(registro)
                estudiante.agregar_nota(materia, nota)      # el Modelo hace el trabajo
                registros[indice] = estudiante.a_diccionario()
                if not gestor.guardar(registros):
                    return False, "No se pudo escribir el archivo"
                return True, f"Nota {nota} agregada en {materia} a {estudiante.obtener_nombre_completo()}"
        return False, f"No existe un estudiante con id {id_estudiante}"
    except Exception as error:
        return False, f"Error inesperado: {error}"


def obtener_promedios(id_estudiante):
    """Devuelve (exito, datos). datos = {'general': x, 'por_materia': {materia: promedio}}."""
    estudiante = obtener_por_id(id_estudiante)
    if estudiante is None:
        return False, f"No existe un estudiante con id {id_estudiante}"
    por_materia = {
        materia: estudiante.obtener_promedio_materia(materia)
        for materia in sorted(estudiante.notas)
    }
    return True, {
        "nombre": estudiante.obtener_nombre_completo(),
        "general": estudiante.obtener_promedio(),
        "por_materia": por_materia,
    }


def materias_ofertadas():
    """CONJUNTO con todas las materias inscritas por todos los estudiantes, sin repetir."""
    todas = set()
    for estudiante in obtener_todos():
        todas |= estudiante.materias        # unión de conjuntos
    return todas


def estudiantes_en_comun(id_a, id_b):
    """Devuelve (exito, resultado). Si exito es True, resultado es un SET de materias."""
    if id_a == id_b:
        return False, "Debe elegir dos estudiantes distintos"
    estudiante_a = obtener_por_id(id_a)
    estudiante_b = obtener_por_id(id_b)
    if estudiante_a is None:
        return False, f"No existe un estudiante con id {id_a}"
    if estudiante_b is None:
        return False, f"No existe un estudiante con id {id_b}"
    # INTERSECCIÓN de conjuntos (la hace el Modelo)
    return True, estudiante_a.materias_en_comun(estudiante_b)
